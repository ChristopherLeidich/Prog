#include "cZeichenKlon.h"

int main(){
	cZeichenKlon k1("a",5);
	cZeichenKlon k2;

	k1.ausgabe();
	cout << k2;

	cout << k1;

	k1++;
	k1++;
	k1++;

	cout << k1;

	k1--;

	cout << k1;

	return 0;

}