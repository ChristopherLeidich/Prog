#include "cZeichenKlon.h"




cZeichenKlon::cZeichenKlon(string ch_in , int anz_in)
{
	anz_in = anz_in + 1;				//Anzahl der zu klonenden Zeichen + 1 Original
	zeichen = ch_in;
	anzahlKlone = anz_in;
}

cZeichenKlon cZeichenKlon::operator++(int anz)			//increment-Funktion unter verwendung des Zeigers this
{
	cZeichenKlon a = *this;
	this->anzahlKlone = anzahlKlone + 1;
	return a;
}

cZeichenKlon cZeichenKlon::operator--(int anz)			//decrementZeiger unter Verwendung des Zeigers this.
{
	cZeichenKlon a = *this;
	this->anzahlKlone = anzahlKlone -1;
	return a;
}



/*int cZeichenKlon::getanz()			//Dies war eine Idee f�r eine Hilfsfunktion die ich im endeffekt nicht ebn�tigt habe
{
	return anzahlKlone;
}*/

void cZeichenKlon::ausgabe()
{
	cout << "Unser derzeitiges Zeichen ist: ";
	for (int i = 0; i < anzahlKlone; i++) {
		cout << zeichen;
	}
	cout << endl << endl;				//doppeltes endl zum erzeugen einer Leerzeile.
}

cZeichenKlon::~cZeichenKlon()
{
}

//Sektion f�r Freunde

ostream& operator<<(ostream& out, cZeichenKlon& c)
{
	out << "Unser derzeitiges Zeichen ist: ";
	for (int i = 0; i < c.anzahlKlone; i++) {
		out << c.zeichen;
	}
	out << endl << endl;		//doppeltes endl zum erzeugen einer Leerzeile f�r ordendlichere Ausgabe
	return out;
}
