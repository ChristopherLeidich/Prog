#pragma once
#include <iostream>

using namespace std;

class cZeichenKlon
{
	string zeichen;
	int anzahlKlone;
public:
	cZeichenKlon(string = "*" ,int = 0);				//Standartkonstruktor
	cZeichenKlon operator++(int);		//Increment-�berladung
	cZeichenKlon operator--(int);		//Decrement-�berladung
	//int getanz();
	void ausgabe();
	friend ostream& operator<<(ostream& out, cZeichenKlon& c);	//ostream �berladung
	~cZeichenKlon();
};

